const KEY="homeRentManager_v1";
let state=JSON.parse(localStorage.getItem(KEY)||"null")||{
 settings:{propertyName:"My Home"},
 tenants:[
  {id:"t1",name:"Demo Tenant",phone:"01700000000",nid:"",flat:"A-101",members:3,joining:"2026-01-01",rent:12000,service:1500,other:500,advance:0,status:"active",outDate:"",notes:"Demo record"}
 ],
 payments:[
  {id:"p1",tenantId:"t1",month:"2026-09",date:"2026-09-05",rent:12000,service:1500,other:500,total:14000,paid:14000,due:0,method:"Cash",ref:"DEMO-001",notes:""}
 ]
};
function save(){localStorage.setItem(KEY,JSON.stringify(state));refresh();}
function money(n){return "৳"+Number(n||0).toLocaleString("en-US")}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function tenant(id){return state.tenants.find(t=>t.id===id)}
function monthNow(){return new Date().toISOString().slice(0,7)}
function showPage(id){
 document.querySelectorAll(".page").forEach(x=>x.classList.add("hidden"));
 document.getElementById(id).classList.remove("hidden");
 document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.page===id));
 if(id==="dashboard")renderDashboard(); if(id==="tenants")renderTenants(); if(id==="payments")renderPayments();
}
document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
function refresh(){renderDashboard();renderTenants();renderPayments();document.getElementById("propertyName").value=state.settings.propertyName||""}
function renderDashboard(){
 const active=state.tenants.filter(t=>t.status==="active");
 const rent=active.reduce((a,t)=>a+Number(t.rent||0),0), service=active.reduce((a,t)=>a+Number(t.service||0),0);
 const paid=state.payments.filter(p=>p.month===monthNow()).reduce((a,p)=>a+Number(p.paid||0),0);
 const expected=active.reduce((a,t)=>a+Number(t.rent||0)+Number(t.service||0)+Number(t.other||0),0);
 const monthPayments=state.payments.filter(p=>p.month===monthNow());
 const recordedTotal=monthPayments.reduce((a,p)=>a+Number(p.total||0),0);
 const due=Math.max(0,expected-recordedTotal);
 sActive.textContent=active.length;sMembers.textContent=active.reduce((a,t)=>a+Number(t.members||0),0);
 sRent.textContent=money(rent);sService.textContent=money(service);sPaid.textContent=money(paid);sDue.textContent=money(due);
 const rows=state.payments.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5);
 recentPayments.innerHTML=rows.length?`<div class="table-wrap"><table><thead><tr><th>Date</th><th>Tenant</th><th>Month</th><th>Total</th><th>Paid</th></tr></thead><tbody>${rows.map(p=>`<tr><td>${esc(p.date)}</td><td>${esc(tenant(p.tenantId)?.name||"Deleted")}</td><td>${esc(p.month)}</td><td>${money(p.total)}</td><td>${money(p.paid)}</td></tr>`).join("")}</tbody></table></div>`:`<div class="empty">No payments yet.</div>`;
}
function periodReport(months){
 const active=state.tenants.filter(t=>t.status==="active");
 let expected=0, paid=0;
 active.forEach(t=>expected+=(Number(t.rent)+Number(t.service)+Number(t.other))*months);
 const start=new Date(); start.setMonth(start.getMonth()-(months-1)); const from=start.toISOString().slice(0,7);
 paid=state.payments.filter(p=>p.month>=from&&p.month<=monthNow()).reduce((a,p)=>a+Number(p.paid||0),0);
 periodResult.innerHTML=`<b>${months} Month Statement</b><br>Expected: <strong>${money(expected)}</strong> · Recorded Paid: <strong>${money(paid)}</strong> · Balance: <strong>${money(Math.max(0,expected-paid))}</strong>`;
}
function renderTenants(){
 const q=(tenantSearch.value||"").toLowerCase(), status=tenantStatus.value;
 const arr=state.tenants.filter(t=>(status==="all"||t.status===status)&&[t.name,t.phone,t.flat].join(" ").toLowerCase().includes(q));
 tenantTable.innerHTML=arr.length?arr.map(t=>`<tr><td><b>${esc(t.name)}</b><br><small>${esc(t.phone)}</small></td><td>${esc(t.flat)}</td><td>${t.members}</td><td>${money(Number(t.rent)+Number(t.service)+Number(t.other))}</td><td><span class="badge ${t.status==="out"?"out":""}">${t.status}</span></td><td><div class="actions"><button class="small" onclick="editTenant('${t.id}')">Edit</button>${t.status==="active"?`<button class="small red" onclick="outTenant('${t.id}')">Out</button>`:`<button class="small" onclick="restoreTenant('${t.id}')">Restore</button>`}<button class="small red" onclick="deleteTenant('${t.id}')">Delete</button></div></td></tr>`).join(""):`<tr><td colspan="6" class="empty">No tenants found.</td></tr>`;
}
function openTenantModal(id=null){
 const t=id?tenant(id):{name:"",phone:"",nid:"",flat:"",members:1,joining:monthNow()+"-01",rent:0,service:0,other:0,advance:0,notes:""};
 modalTitle.textContent=id?"Edit Tenant":"Add Tenant";
 modalBody.innerHTML=`<form id="tenantForm"><div class="form-grid">
 <label>Name<input name="name" required value="${esc(t.name)}"></label><label>Mobile<input name="phone" value="${esc(t.phone)}"></label>
 <label>NID/ID<input name="nid" value="${esc(t.nid)}"></label><label>Flat/Room<input name="flat" required value="${esc(t.flat)}"></label>
 <label>Member Count<input name="members" type="number" min="1" value="${t.members}"></label><label>Joining Date<input name="joining" type="date" value="${t.joining}"></label>
 <label>Monthly Rent<input name="rent" type="number" min="0" value="${t.rent}"></label><label>Service Charge<input name="service" type="number" min="0" value="${t.service}"></label>
 <label>Other Charge<input name="other" type="number" min="0" value="${t.other}"></label><label>Advance<input name="advance" type="number" min="0" value="${t.advance}"></label>
 <label class="span2">Notes<textarea name="notes">${esc(t.notes)}</textarea></label></div>
 <div class="modal-actions"><button type="button" class="ghost" onclick="closeModal()">Cancel</button><button class="primary">Save Tenant</button></div></form>`;
 tenantForm.onsubmit=e=>{e.preventDefault();const f=new FormData(tenantForm);const obj=Object.fromEntries(f);["members","rent","service","other","advance"].forEach(k=>obj[k]=Number(obj[k]||0));obj.status=t.status||"active";obj.outDate=t.outDate||"";obj.id=id||("t"+Date.now()); if(id){Object.assign(tenant(id),obj)}else state.tenants.push(obj);closeModal();save()};modal.classList.remove("hidden");
}
function editTenant(id){openTenantModal(id)}
function outTenant(id){const t=tenant(id);if(confirm(`Mark ${t.name} as OUT tenant?`)){t.status="out";t.outDate=new Date().toISOString().slice(0,10);save()}}
function restoreTenant(id){tenant(id).status="active";tenant(id).outDate="";save()}
function deleteTenant(id){if(confirm("Delete this tenant permanently?")){state.tenants=state.tenants.filter(t=>t.id!==id);save()}}
function openPaymentModal(){
 const active=state.tenants.filter(t=>t.status==="active");
 modalTitle.textContent="Record Payment";
 modalBody.innerHTML=`<form id="paymentForm"><div class="form-grid">
 <label class="span2">Tenant<select name="tenantId" required>${active.map(t=>`<option value="${t.id}">${esc(t.name)} — ${esc(t.flat)}</option>`).join("")}</select></label>
 <label>Month<input name="month" type="month" value="${monthNow()}" required></label><label>Date<input name="date" type="date" value="${new Date().toISOString().slice(0,10)}" required></label>
 <label>Rent<input name="rent" type="number" min="0" value="0"></label><label>Service Charge<input name="service" type="number" min="0" value="0"></label>
 <label>Other Charge<input name="other" type="number" min="0" value="0"></label><label>Paid Amount<input name="paid" type="number" min="0" value="0"></label>
 <label>Payment Method<select name="method"><option>Cash</option><option>bKash</option><option>Bank</option><option>Other</option></select></label><label>Reference<input name="ref" placeholder="Txn/receipt no."></label>
 <label class="span2">Notes<textarea name="notes"></textarea></label></div><div class="modal-actions"><button type="button" class="ghost" onclick="closeModal()">Cancel</button><button class="primary">Save Payment</button></div></form>`;
 paymentForm.onsubmit=e=>{e.preventDefault();const f=new FormData(paymentForm),o=Object.fromEntries(f);["rent","service","other","paid"].forEach(k=>o[k]=Number(o[k]||0));o.total=o.rent+o.service+o.other;o.due=Math.max(0,o.total-o.paid);o.id="p"+Date.now();state.payments.push(o);closeModal();save()};modal.classList.remove("hidden");
}
function renderPayments(){
 const q=(paymentSearch.value||"").toLowerCase(), current=paymentPeriod.value==="month";
 let arr=state.payments.filter(p=>(!current||p.month===monthNow())&&[p.month,tenant(p.tenantId)?.name||"",tenant(p.tenantId)?.flat||""].join(" ").toLowerCase().includes(q)).sort((a,b)=>b.date.localeCompare(a.date));
 paymentTable.innerHTML=arr.length?arr.map(p=>`<tr><td>${esc(p.date)}</td><td>${esc(tenant(p.tenantId)?.name||"Deleted")}</td><td>${esc(p.month)}</td><td>${money(p.total)}</td><td>${money(p.paid)}</td><td>${money(p.due)}</td><td><div class="actions"><button class="small" onclick="printReceipt('${p.id}')">Receipt</button><button class="small red" onclick="deletePayment('${p.id}')">Delete</button></div></td></tr>`).join(""):`<tr><td colspan="7" class="empty">No payments found.</td></tr>`;
}
function deletePayment(id){if(confirm("Delete payment?")){state.payments=state.payments.filter(p=>p.id!==id);save()}}
function printReceipt(id){
 const p=state.payments.find(x=>x.id===id),t=tenant(p.tenantId),w=window.open("","_blank");
 w.document.write(`<html><head><title>Receipt</title><style>body{font-family:Arial;padding:30px;max-width:600px;margin:auto}.row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #eee}.total{font-weight:bold;font-size:18px}</style></head><body><h2>🏠 ${esc(state.settings.propertyName)}</h2><p>Rent Payment Receipt</p><hr><p><b>Tenant:</b> ${esc(t?.name||"Deleted")}<br><b>Flat:</b> ${esc(t?.flat||"")}<br><b>Month:</b> ${esc(p.month)}<br><b>Date:</b> ${esc(p.date)}</p><div class="row"><span>Rent</span><b>${money(p.rent)}</b></div><div class="row"><span>Service Charge</span><b>${money(p.service)}</b></div><div class="row"><span>Other Charge</span><b>${money(p.other)}</b></div><div class="row total"><span>Total</span><b>${money(p.total)}</b></div><div class="row"><span>Paid</span><b>${money(p.paid)}</b></div><div class="row"><span>Due</span><b>${money(p.due)}</b></div><p>Payment: ${esc(p.method)} ${p.ref?"· "+esc(p.ref):""}</p><script>window.print()<\/script></body></html>`);w.document.close()
}
function generateReport(){
 const from=reportFrom.value||monthNow(),to=reportTo.value||monthNow();
 const arr=state.payments.filter(p=>p.month>=from&&p.month<=to);
 const total=arr.reduce((a,p)=>a+p.total,0),paid=arr.reduce((a,p)=>a+p.paid,0),due=arr.reduce((a,p)=>a+p.due,0);
 reportBox.innerHTML=`<div class="receipt"><h2>${esc(state.settings.propertyName)}</h2><p>Statement: ${esc(from)} → ${esc(to)}</p><div class="receipt-row"><span>Transactions</span><b>${arr.length}</b></div><div class="receipt-row"><span>Total Charged</span><b>${money(total)}</b></div><div class="receipt-row"><span>Total Paid</span><b>${money(paid)}</b></div><div class="receipt-row total"><span>Total Due</span><b>${money(due)}</b></div><hr>${arr.map(p=>`<div class="receipt-row"><span>${esc(p.month)} — ${esc(tenant(p.tenantId)?.name||"Deleted")}</span><b>${money(p.paid)}</b></div>`).join("")}</div>`;
}
function saveSettings(){state.settings.propertyName=propertyName.value.trim()||"My Home";save();alert("Settings saved.")}
function exportData(){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(state,null,2)],{type:"application/json"}));a.download="home-rent-backup.json";a.click();URL.revokeObjectURL(a.href)}
function importData(e){const file=e.target.files[0];if(!file)return;const r=new FileReader();r.onload=()=>{try{const d=JSON.parse(r.result);if(!d.tenants||!d.payments)throw Error();state=d;save();alert("Backup restored.")}catch{alert("Invalid backup file.")}};r.readAsText(file)}
function resetData(){if(confirm("This will erase all local data. Continue?")){localStorage.removeItem(KEY);location.reload()}}
function closeModal(){modal.classList.add("hidden")}
document.getElementById("demoBtn").onclick=()=>{loginView.classList.add("hidden");appView.classList.remove("hidden");userLabel.textContent="Demo Admin";refresh()};
document.getElementById("loginBtn").onclick=()=>{const e=loginEmail.value.trim(),p=loginPassword.value;if(e==="admin@demo.com"&&p==="123456"){loginView.classList.add("hidden");appView.classList.remove("hidden");userLabel.textContent=e;refresh()}else loginMsg.textContent="Demo credentials: admin@demo.com / 123456 — or use Demo Mode."};
document.getElementById("logoutBtn").onclick=()=>{appView.classList.add("hidden");loginView.classList.remove("hidden")};
refresh();
