HOME RENT MANAGEMENT — GITHUB READY

This is a fully working browser/local database version.
Demo login:
Email: admin@demo.com
Password: 123456

You can also click "Use Demo Mode".

Features:
- Admin login/demo mode
- Dashboard
- Tenant add/edit/out/restore/delete
- Member count
- Rent, service charge, other charge, advance
- Payment records
- Paid/due calculation
- 1/3/6/12 month quick statement
- Search/filter
- Printable receipts
- Date-range reports
- JSON backup/restore
- GitHub Pages compatible
- Responsive mobile UI

IMPORTANT:
This ZIP currently uses browser localStorage, so it works immediately without any API key.
For multi-device/cloud database use, connect Firebase later. Do NOT put Firebase Admin SDK credentials in frontend.

GITHUB PAGES:
1. Extract ZIP.
2. Upload all files to a GitHub repository.
3. Keep index.html at repository root.
4. Settings -> Pages -> Deploy from branch -> main/root.
5. Open the generated Pages URL.

DEMO LOGIN IS NOT SECURE PRODUCTION AUTHENTICATION.
For real production use, Firebase Authentication + Firestore security rules should replace demo/local authentication.
